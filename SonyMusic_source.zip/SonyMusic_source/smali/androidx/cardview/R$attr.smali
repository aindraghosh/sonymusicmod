.class public final Landroidx/cardview/R$attr;
.super Ljava/lang/Object;


# static fields
.field public static final cardViewStyle:I = 0x7f040064
