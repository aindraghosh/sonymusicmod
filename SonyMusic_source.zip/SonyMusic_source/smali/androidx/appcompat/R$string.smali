.class public final Landroidx/appcompat/R$string;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_up_description:I = 0x7f100001

.field public static final abc_menu_alt_shortcut_label:I = 0x7f100014

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f100015

.field public static final abc_menu_delete_shortcut_label:I = 0x7f100016

.field public static final abc_menu_enter_shortcut_label:I = 0x7f100017

.field public static final abc_menu_function_shortcut_label:I = 0x7f100018

.field public static final abc_menu_meta_shortcut_label:I = 0x7f100019

.field public static final abc_menu_shift_shortcut_label:I = 0x7f10001a

.field public static final abc_menu_space_shortcut_label:I = 0x7f10001b

.field public static final abc_menu_sym_shortcut_label:I = 0x7f10001c

.field public static final abc_prepend_shortcut_label:I = 0x7f10001d

.field public static final abc_searchview_description_search:I = 0x7f100021
