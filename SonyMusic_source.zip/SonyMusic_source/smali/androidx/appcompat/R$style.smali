.class public final Landroidx/appcompat/R$style;
.super Ljava/lang/Object;


# static fields
.field public static final Animation_AppCompat_Tooltip:I = 0x7f110004

.field public static final Base_Widget_AppCompat_DrawerArrowToggle:I = 0x7f1100af

.field public static final Theme_AppCompat_CompactMenu:I = 0x7f110194

.field public static final Theme_AppCompat_Light:I = 0x7f1101a0
