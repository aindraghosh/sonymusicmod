.class public final Landroidx/appcompat/R$attr;
.super Ljava/lang/Object;


# static fields
.field public static final actionBarPopupTheme:I = 0x7f040002

.field public static final actionBarSize:I = 0x7f040003

.field public static final actionBarStyle:I = 0x7f040005

.field public static final actionBarTabStyle:I = 0x7f040007

.field public static final actionBarTabTextStyle:I = 0x7f040008

.field public static final actionBarTheme:I = 0x7f040009

.field public static final actionBarWidgetTheme:I = 0x7f04000a

.field public static final actionDropDownStyle:I = 0x7f04000c

.field public static final actionModePopupWindowStyle:I = 0x7f040017

.field public static final actionModeStyle:I = 0x7f04001b

.field public static final actionOverflowButtonStyle:I = 0x7f04001d

.field public static final actionOverflowMenuStyle:I = 0x7f04001e

.field public static final alertDialogCenterButtons:I = 0x7f040024

.field public static final alertDialogStyle:I = 0x7f040025

.field public static final alertDialogTheme:I = 0x7f040026

.field public static final autoCompleteTextViewStyle:I = 0x7f04002f

.field public static final buttonStyle:I = 0x7f04005a

.field public static final checkboxStyle:I = 0x7f040066

.field public static final colorAccent:I = 0x7f04008c

.field public static final colorButtonNormal:I = 0x7f04008e

.field public static final colorControlActivated:I = 0x7f04008f

.field public static final colorControlHighlight:I = 0x7f040090

.field public static final colorControlNormal:I = 0x7f040091

.field public static final colorPrimary:I = 0x7f040093

.field public static final colorPrimaryDark:I = 0x7f040094

.field public static final colorSwitchThumbNormal:I = 0x7f040098

.field public static final dialogTheme:I = 0x7f0400b9

.field public static final drawerArrowStyle:I = 0x7f0400c3

.field public static final dropDownListViewStyle:I = 0x7f0400c6

.field public static final editTextStyle:I = 0x7f0400cc

.field public static final homeAsUpIndicator:I = 0x7f040107

.field public static final imageButtonStyle:I = 0x7f040116

.field public static final isLightTheme:I = 0x7f04011b

.field public static final listMenuViewStyle:I = 0x7f040143

.field public static final panelMenuListTheme:I = 0x7f040176

.field public static final radioButtonStyle:I = 0x7f040197

.field public static final ratingBarStyle:I = 0x7f040198

.field public static final searchViewStyle:I = 0x7f0401a4

.field public static final seekBarStyle:I = 0x7f0401a7

.field public static final spinnerStyle:I = 0x7f0401bb

.field public static final switchStyle:I = 0x7f0401d6

.field public static final textColorSearchUrl:I = 0x7f04020b

.field public static final toolbarNavigationButtonStyle:I = 0x7f040227

.field public static final toolbarStyle:I = 0x7f040228
