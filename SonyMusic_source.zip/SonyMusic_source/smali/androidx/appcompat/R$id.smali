.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# static fields
.field public static final action_bar:I = 0x7f090028

.field public static final action_bar_activity_content:I = 0x7f090029

.field public static final action_bar_container:I = 0x7f09002a

.field public static final action_bar_subtitle:I = 0x7f09002d

.field public static final action_bar_title:I = 0x7f09002e

.field public static final action_context_bar:I = 0x7f090030

.field public static final action_menu_presenter:I = 0x7f090035

.field public static final action_mode_bar_stub:I = 0x7f090037

.field public static final action_mode_close_button:I = 0x7f090038

.field public static final alertTitle:I = 0x7f090046

.field public static final buttonPanel:I = 0x7f09005e

.field public static final content:I = 0x7f09007a

.field public static final contentPanel:I = 0x7f09007b

.field public static final custom:I = 0x7f090085

.field public static final customPanel:I = 0x7f090086

.field public static final decor_content_parent:I = 0x7f090089

.field public static final edit_query:I = 0x7f0900a6

.field public static final group_divider:I = 0x7f0900c5

.field public static final message:I = 0x7f09011f

.field public static final parentPanel:I = 0x7f090178

.field public static final scrollIndicatorDown:I = 0x7f0901b2

.field public static final scrollIndicatorUp:I = 0x7f0901b3

.field public static final scrollView:I = 0x7f0901b4

.field public static final search_button:I = 0x7f0901b9

.field public static final search_close_btn:I = 0x7f0901ba

.field public static final search_edit_frame:I = 0x7f0901bb

.field public static final search_go_btn:I = 0x7f0901bc

.field public static final search_mag_icon:I = 0x7f0901be

.field public static final search_plate:I = 0x7f0901bf

.field public static final search_src_text:I = 0x7f0901c0

.field public static final search_voice_btn:I = 0x7f0901c1

.field public static final shortcut:I = 0x7f0901c9

.field public static final spacer:I = 0x7f0901da

.field public static final split_action_bar:I = 0x7f0901dc

.field public static final submenuarrow:I = 0x7f0901e8

.field public static final submit_area:I = 0x7f0901e9

.field public static final textSpacerNoButtons:I = 0x7f0901ff

.field public static final textSpacerNoTitle:I = 0x7f090200

.field public static final title:I = 0x7f090214

.field public static final titleDividerNoCustom:I = 0x7f090215

.field public static final title_template:I = 0x7f090217

.field public static final topPanel:I = 0x7f09021b
